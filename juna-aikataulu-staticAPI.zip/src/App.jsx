import React from "react";
import FetchData from "./FetchData";

function App() {
  return (
    <FetchData></FetchData>
  )
}

export default App